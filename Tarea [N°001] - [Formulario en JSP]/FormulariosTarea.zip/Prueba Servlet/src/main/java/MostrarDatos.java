

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class MostrarDatos
 */
public class MostrarDatos extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MostrarDatos() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		String nombre = request.getParameter("nombre");
		String usuario = request.getParameter("usuario");
		String contraseña = request.getParameter("contra");
		String email = request.getParameter("email");
		
		String passValid = "Invalida";
			if(contraseña.length() >= 10) {
				passValid = "Valida";
			}
			
		PrintWriter salida = response.getWriter();
		salida.println("<html><body>");
		salida.println("<h1 style='color:black; font-family:arial;'>La contraseña es "+passValid+"</h1>");
		salida.println("</body></html>");
		
		try {
			out.println("<!DOCTYPE html>");
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Datos del Formulario</title>");
			out.println("</head>");
			out.println("<body>");
			out.println("<h2 style='color:red; font-family:arial;'>Tu nombre es: "+nombre+" </h2>");
			out.println("<h2 style='color:orange; font-family:arial;'>Tu usuario es: "+usuario+" </h2>");
			out.println("<h2 style='color:blue; font-family:arial;'>Tu correo es: "+email+" </h2>");
			out.println("</body>");
			out.println("</html>");
		}
		
		finally {
			out.close();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
